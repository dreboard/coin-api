create
    definer = root@localhost function FuncCountAllVarietiesByCoinID(c_id int) returns int
    comment 'Get count of all variety by coinID'
    reads sql data
BEGIN
    DECLARE varietyCount INT;
    SELECT COUNT(cv.variety)
    INTO varietyCount
    FROM coins_variety cv
    WHERE cv.coin_id = c_id;
    RETURN varietyCount;
END;

