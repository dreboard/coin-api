create
    definer = root@localhost procedure CoinTypeDistinctMintMarkYears(IN c_type int) reads sql data
BEGIN
    SELECT DISTINCT mintmark FROM coins WHERE cointypes_id = c_type ORDER BY coinYear ASC;
END;

