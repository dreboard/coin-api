create
    definer = root@localhost function FuncTypeGetCount(c_type varchar(30)) returns int
    comment 'Get count of type'
    reads sql data
BEGIN
    DECLARE designsCollected INT;
    SELECT COUNT(DISTINCT coins.coinVersion)
    INTO designsCollected
    FROM coins
    WHERE coins.coinType = c_type;
    RETURN designsCollected;
END;

