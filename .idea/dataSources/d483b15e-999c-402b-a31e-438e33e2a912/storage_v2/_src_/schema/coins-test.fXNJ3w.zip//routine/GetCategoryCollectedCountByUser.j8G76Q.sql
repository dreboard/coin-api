create
    definer = root@localhost procedure GetCategoryCollectedCountByUser(IN cat varchar(20), IN id int)
BEGIN
    SELECT * FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
      WHERE collection.userID = id
      AND coins.coinCategory = cat;
  END;

