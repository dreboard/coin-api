create
    definer = root@localhost procedure CoinTypeGetCategory(IN coinType varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Details not found';
    SELECT coinCategory FROM coins WHERE coinType = coinType LIMIT 1;
  END;

