create
    definer = root@localhost procedure UserTotalInvestmentSumByType(IN id int, IN type varchar(100))
BEGIN
    -- Collection::getSumTypeCount()
    SELECT COALESCE(sum(purchasePrice), 0.00)
    FROM collection
      INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE collection.userID = id
          AND coins.coinType = type;
  END;

