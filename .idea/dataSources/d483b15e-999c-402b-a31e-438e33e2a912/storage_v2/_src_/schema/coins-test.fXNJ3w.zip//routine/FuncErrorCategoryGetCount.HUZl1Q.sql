create
    definer = root@localhost function FuncErrorCategoryGetCount(e_cat varchar(100)) returns int
    comment 'Get count of Error Category'
    reads sql data
BEGIN
    DECLARE errorCount INT;
    SELECT
           COUNT(DISTINCT(ce.sub_category))
    INTO errorCount
	FROM coins_errors ce
	WHERE ce.category = e_cat AND ce.sub_category IS NOT NULL ;
    RETURN errorCount;
END;

