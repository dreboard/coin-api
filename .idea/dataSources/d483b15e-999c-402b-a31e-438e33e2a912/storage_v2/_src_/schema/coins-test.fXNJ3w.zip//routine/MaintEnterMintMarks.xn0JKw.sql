create
    definer = root@localhost procedure MaintEnterMintMarks()
BEGIN

DECLARE coinTypeVar VARCHAR(255);
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE coinTypeCusor CURSOR FOR SELECT coinType FROM cointypes2;

 -- declare NOT FOUND handler
DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

OPEN coinTypeCusor;
get_coinType: LOOP

    FETCH coinTypeCusor INTO coinTypeVar;
    IF v_finished = 1 THEN
        LEAVE get_coinType;
    END IF;

    UPDATE `cointypes` SET `mintMarks` = (SELECT GROUP_CONCAT(DISTINCT coins.mintMark) FROM coins WHERE coins.coinType = coinTypeVar) WHERE coinType = coinTypeVar;

END LOOP get_coinType;
CLOSE coinTypeCusor;

END;

