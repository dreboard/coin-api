create
    definer = root@localhost procedure CoinListSubCategoryAll() comment 'List of subcategories' reads sql data
BEGIN
    SELECT DISTINCT(coinSubCategory) FROM coins;
  END;

