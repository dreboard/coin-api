create view viewmoderncategories as
select distinct `cc`.`coinCategory` AS `coinCategory`
from (`coins-test`.`coincategories` `cc`
         join `coins-test`.`coins` `c` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinYear` between 1965 and year(curdate())
  and `cc`.`coinCategory` <> 'No Category'
order by `cc`.`denomination`;

