create
    definer = root@localhost procedure CollectedListCoinByIdAndGrade(IN c_id int(10), IN u_id int(10), IN co_grade varchar(10))
    comment 'Get list of coins same id and same grade'
    reads sql data
BEGIN
    SELECT
           c.id, co.coinNickname, co.coinGrade
	FROM collected co
    INNER JOIN coins c ON c.id = co.coinID
	WHERE co.coinID = c_id AND co.coinGrade = co_grade AND co.userID = u_id;
  END;

