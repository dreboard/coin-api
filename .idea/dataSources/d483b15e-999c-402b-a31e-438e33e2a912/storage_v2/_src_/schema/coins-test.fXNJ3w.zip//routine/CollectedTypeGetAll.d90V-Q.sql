create
    definer = root@localhost procedure CollectedTypeGetAll(IN type varchar(100), IN u_id int(100))
BEGIN
    SELECT co.* FROM collected co
    INNER JOIN coins c ON co.coinID = c.id
    WHERE c.cointypes_id = type AND co.userID = u_id
    ORDER BY c.coinYear ASC;
  END;

