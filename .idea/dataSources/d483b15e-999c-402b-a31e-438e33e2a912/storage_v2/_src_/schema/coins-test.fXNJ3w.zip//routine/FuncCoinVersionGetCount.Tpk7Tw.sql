create
    definer = root@localhost function FuncCoinVersionGetCount(version varchar(50)) returns int
    comment 'Get count of coinVersion'
    reads sql data
BEGIN
    DECLARE versionsCollected INT;
    SELECT COUNT(coinVersion) INTO versionsCollected FROM coins
    WHERE coins.coinVersion = version;
    RETURN versionsCollected;
  END;

