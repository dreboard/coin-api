create
    definer = root@localhost procedure _TestType(IN cointype varchar(100))
BEGIN
    DECLARE type VARCHAR(100);
    DECLARE denom DECIMAL;
    DECLARE type_cursor CURSOR FOR 
      SELECT coins.coinType, coins.denomination FROM coins 
        WHERE coins.coinType = cointype ORDER BY coins.coinYear DESC;
    -- open
    OPEN type_cursor;
    LOOP 
      FETCH type_cursor INTO type, denom;
      SELECT concat('Coin type', type), concat(' value of', denom);
    END LOOP;    
    CLOSE type_cursor;
  END;

