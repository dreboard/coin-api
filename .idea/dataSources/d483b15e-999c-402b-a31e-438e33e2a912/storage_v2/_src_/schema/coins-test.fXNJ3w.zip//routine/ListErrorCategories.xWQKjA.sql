create
    definer = root@localhost procedure ListErrorCategories() comment 'Get error categories' reads sql data
BEGIN
    SELECT
           DISTINCT(co.category)
	FROM coins_errors co ORDER BY co.category;
  END;

