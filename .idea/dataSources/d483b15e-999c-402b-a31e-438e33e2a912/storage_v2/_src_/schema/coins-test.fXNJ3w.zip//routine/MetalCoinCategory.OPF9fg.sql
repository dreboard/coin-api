create
    definer = root@localhost procedure MetalCoinCategory(IN metal varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Metal not found';
    CASE metal
      WHEN  'Silver' THEN
      SELECT DISTINCT( coinCategory ) FROM coins WHERE coins.coinMetal = metal AND commemorative = '1' ORDER BY denomination ASC;
    ELSE
      SELECT DISTINCT( coinCategory ) FROM coins WHERE coins.coinMetal = metal ORDER BY denomination ASC;
    END CASE;

  END;

