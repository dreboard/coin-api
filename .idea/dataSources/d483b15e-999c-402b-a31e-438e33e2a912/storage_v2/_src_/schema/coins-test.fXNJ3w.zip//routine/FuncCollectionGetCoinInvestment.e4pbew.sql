create
    definer = root@localhost function FuncCollectionGetCoinInvestment(c_id int, u_id int) returns float
    comment 'Get sum of coinID'
    reads sql data
BEGIN
    DECLARE invested FLOAT;
    SELECT COALESCE(sum(cp.purchasePrice), 0.00)
    INTO invested
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
    WHERE co.userID = u_id
      AND co.coinID = c_id;
    RETURN invested;
END;

