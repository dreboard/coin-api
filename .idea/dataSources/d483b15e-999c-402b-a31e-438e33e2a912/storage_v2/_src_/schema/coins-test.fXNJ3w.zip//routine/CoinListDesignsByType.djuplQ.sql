create
    definer = root@localhost procedure CoinListDesignsByType(IN c_type int)
    comment 'Get designs by coin Type'
    reads sql data
BEGIN
    SELECT DISTINCT(design) FROM `coins` WHERE design <> 'none' AND cointypes_id = c_type;
END;

