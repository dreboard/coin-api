create
    definer = root@localhost procedure DistinctVarietyCountsByYearAndType(IN c_year varchar(20), IN c_type varchar(20))
    comment 'Get Liberty Broken Die list by BIE type'
    reads sql data
BEGIN
    SELECT
           DISTINCT cv.variety, cv.sub_type, c.mintMark, COUNT(cv.designation) AS varCount
    FROM coins_variety cv
             INNER JOIN coins c ON cv.coin_id = c.id
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
    WHERE c.`coinYear` = c_year
      AND c.cointypes_id = c_type
    GROUP BY cv.designation ORDER BY cv.designation;
END;

