create
    definer = root@localhost procedure CoinGetDesignByTypeCollected(IN type varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'dates not found';
    SELECT DISTINCT(design) FROM coins WHERE design <> 'none' AND coinType = type;
  END;

