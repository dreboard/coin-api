create
    definer = root@localhost function FuncSubCategoryGetCount(subcat varchar(50)) returns int
    comment 'Get count of all SubCategory coins'
    reads sql data
BEGIN
    DECLARE coinSubCategoryCollected INT;
    SELECT COUNT(coinSubCategory) INTO coinSubCategoryCollected FROM coins
    WHERE coins.coinSubCategory = subcat;
    RETURN coinSubCategoryCollected;
  END;

