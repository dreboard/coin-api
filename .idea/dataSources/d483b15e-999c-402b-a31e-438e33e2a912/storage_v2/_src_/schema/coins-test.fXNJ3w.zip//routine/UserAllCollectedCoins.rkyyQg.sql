create
    definer = root@localhost procedure UserAllCollectedCoins(IN id int)
BEGIN
    SELECT COUNT(*) FROM collection WHERE userID = id;
  END;

