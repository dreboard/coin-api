create
    definer = root@localhost procedure CoinListTypeOfBieVariety(IN c_var varchar(20))
    comment 'Get Liberty Broken Die list by BIE type'
    reads sql data
BEGIN
    SELECT
         CASE
            WHEN cv.sub_type != 'None' THEN CONCAT(c.coinName, " ", COALESCE(cv.sub_type, ''))
            ELSE c.coinName
        END AS coinName,
           cv.description, cv.designation
    FROM coins_variety cv
             INNER JOIN coins c ON cv.coin_id = c.id
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE cv.`description` = c_var
      AND cv.`grouping` = 'Liberty Broken Die'
    ORDER BY c.coinYear;
END;

