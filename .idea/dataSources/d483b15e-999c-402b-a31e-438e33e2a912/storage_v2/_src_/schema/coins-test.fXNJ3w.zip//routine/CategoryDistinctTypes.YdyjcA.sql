create
    definer = root@localhost procedure CategoryDistinctTypes(IN cat varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Types not found';
    SELECT DISTINCT coinType FROM coins WHERE coinCategory = cat ORDER BY coinYear DESC;
  END;

