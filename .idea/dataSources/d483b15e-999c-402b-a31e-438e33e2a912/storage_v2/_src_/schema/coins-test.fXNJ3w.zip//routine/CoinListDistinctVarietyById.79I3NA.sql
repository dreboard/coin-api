create
    definer = root@localhost procedure CoinListDistinctVarietyById(IN c_id int(10))
    comment 'Get variety with same coinID.'
    reads sql data
BEGIN
      SELECT DISTINCT (cv.variety)
      FROM coins_variety cv
      WHERE cv.coin_id = c_id
      ORDER BY udf_NaturalSortFormat(cv.variety, 15, ".");
  END;

