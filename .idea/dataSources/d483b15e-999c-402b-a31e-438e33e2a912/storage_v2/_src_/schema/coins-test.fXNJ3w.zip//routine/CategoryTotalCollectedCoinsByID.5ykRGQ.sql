create
    definer = root@localhost procedure CategoryTotalCollectedCoinsByID(IN category varchar(50), IN id int)
BEGIN
  SELECT COUNT(*) FROM collection
            INNER JOIN coins ON collection.coinID = coins.coinID
            WHERE collection.userID = id AND coins.coinCategory = category;
END;

