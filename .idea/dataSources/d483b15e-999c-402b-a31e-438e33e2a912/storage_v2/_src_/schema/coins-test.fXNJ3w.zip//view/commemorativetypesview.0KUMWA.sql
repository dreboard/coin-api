create view commemorativetypesview as
select distinct `coins-test`.`coins`.`coinType` AS `coinType`
from `coins-test`.`coins`
where `coins-test`.`coins`.`commemorative` = 1
order by `coins-test`.`coins`.`denomination` desc;

