create
    definer = root@localhost procedure CoinListCategoryFromSubCategory(IN c_sub varchar(100))
    comment 'Get coin by id.'
    reads sql data
BEGIN
    SELECT coinCategory FROM coins WHERE coinVersion = c_sub LIMIT 1;

    SELECT DISTINCT(cc.coinCategory)
    FROM coincategories cc
             INNER JOIN coins c ON cc.id = c.coincats_id
    WHERE c.coinSubCategory = c_sub;

END;

