create view viewallcointypes as
select `ct`.`coinType` AS `coinType`, `cc`.`denomination` AS `denomination`
from (`coins-test`.`cointypes` `ct`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `ct`.`coincats_id`))
where `ct`.`coinType` <> 'No Type'
  and left(`ct`.`coinType`, 5) <> 'Mixed'
order by `cc`.`denomination`, `ct`.`initial`;

