create
    definer = root@localhost procedure MintSetGetAllFromYear(IN cy int)
    comment 'Get MintSet all same year.'
    reads sql data
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT mintsetID, setName, coinType, coinYear FROM mintset WHERE coinYear = ?';
    EXECUTE dynamic_statement USING cy;
    DEALLOCATE PREPARE dynamic_statement;
END;

