create
    definer = root@localhost procedure CategoryGetInfo(IN c_cat int)
BEGIN
    SELECT cc.id, cc.coinCategory, cc.typeCount
    FROM coincategories cc
    WHERE cc.id = c_cat;
END;

