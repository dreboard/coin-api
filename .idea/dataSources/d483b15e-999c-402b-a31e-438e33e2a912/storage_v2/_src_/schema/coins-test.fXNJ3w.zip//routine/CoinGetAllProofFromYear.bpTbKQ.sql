create
    definer = root@localhost procedure CoinGetAllProofFromYear(IN cy int)
    comment 'Get Commemorative all same year.'
    reads sql data
BEGIN
    SELECT id, coinName, coinType, coinYear, coinVersion
        FROM coins
        WHERE coins.coinYear = cy AND coins.strike IN ('Proof', 'Reverse Proof')  ORDER BY coins.denomination;

END;

