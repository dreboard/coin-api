create
    definer = root@localhost function FuncPrefixHighestGrade(c_id int(20)) returns varchar(3)
BEGIN
    DECLARE gradePrefix VARCHAR(20);
    DECLARE PREFIX VARCHAR(3);
    SELECT co.strike INTO gradePrefix
    FROM coins co
    WHERE co.id = c_id;

        IF gradePrefix = "Business" THEN
        SET PREFIX = 'MS-';
        ELSEIF gradePrefix = "Proof" THEN
        SET PREFIX = 'PR-';
        ELSEIF gradePrefix = "Reverse Proof" THEN
        SET PREFIX = 'PR-';
        ELSEIF gradePrefix = "Special Mint" THEN
        SET PREFIX = 'SP-';
    END IF;
    RETURN PREFIX;
END;

