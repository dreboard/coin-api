create
    definer = root@localhost function FuncCollectionCountTypesByCategory(c_cat varchar(20)) returns int
BEGIN
    DECLARE typesCollected INT;
    SELECT COUNT(DISTINCT ct.coinType) INTO typesCollected FROM collected co
    INNER JOIN coins c ON c.id = co.coinID
    INNER JOIN cointypes ct ON c.cointypes_id = ct.id
    WHERE c.coincats_id = c_cat;
    RETURN typesCollected;
  END;

