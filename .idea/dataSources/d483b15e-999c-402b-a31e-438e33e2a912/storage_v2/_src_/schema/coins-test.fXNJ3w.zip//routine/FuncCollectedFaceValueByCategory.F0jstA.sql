create
    definer = root@localhost function FuncCollectedFaceValueByCategory(cat_id int, u_id int, catDenom float) returns float
    comment 'Get sum of category investment'
    reads sql data
BEGIN
    DECLARE face_val FLOAT;
    SELECT COUNT(co.id)
    INTO face_val
    FROM collected co
             INNER JOIN coins c ON c.id = co.coinID
             INNER JOIN coincategories cc ON c.coincats_id = cc.id
    WHERE co.userID = u_id
      AND cc.id = cat_id;
    RETURN FORMAT(face_val * catDenom, 4);
END;

