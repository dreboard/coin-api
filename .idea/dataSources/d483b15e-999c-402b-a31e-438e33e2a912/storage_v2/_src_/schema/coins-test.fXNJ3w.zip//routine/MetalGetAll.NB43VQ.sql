create
    definer = root@localhost procedure MetalGetAll(IN metal varchar(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Metal not found';

    CASE metal
      WHEN  'Silver' THEN
      SELECT * FROM coins WHERE coins.coinMetal = metal
      AND commemorative = '1'
      ORDER BY coinName ASC;
    ELSE
      SELECT * FROM coins WHERE coins.coinMetal = metal
      ORDER BY coinName ASC;
    END CASE;

  END;

