create view viewallplatinumcoins as
select `c`.`id`            AS `id`,
       `c`.`mintMark`      AS `mintMark`,
       `c`.`coinYear`      AS `coinYear`,
       `c`.`coinCategory`  AS `coinCategory`,
       `c`.`coinType`      AS `coinType`,
       `c`.`coinName`      AS `coinName`,
       `c`.`strike`        AS `strike`,
       `c`.`commemorative` AS `commemorative`
from (`coins-test`.`coins` `c`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinMetal` = 'Platinum'
order by `c`.`coinYear`, `cc`.`denomination`;

