create
    definer = root@localhost procedure CollectionSaveCoinPurchase(IN co_id int, IN c_from varchar(50),
                                                                  IN c_date datetime, IN c_price varchar(50),
                                                                  IN c_ebay varchar(50), IN c_shop varchar(50),
                                                                  IN c_url varchar(50), IN c_name varchar(50),
                                                                  IN c_city varchar(50))
    comment 'Save coin purchase'
    modifies sql data
BEGIN
    INSERT INTO `collected_purchase`
        (`id`, `collected_id`, `purchaseFrom`, `purchaseDate`, `purchasePrice`, `ebaySellerID`, `shopName`, `shopUrl`, `showName`, `showCity`, `saved`)
    VALUES
        (NULL, co_id, c_from, c_date, c_price, c_ebay, c_shop, c_url, c_name, c_city, current_timestamp());
END;

