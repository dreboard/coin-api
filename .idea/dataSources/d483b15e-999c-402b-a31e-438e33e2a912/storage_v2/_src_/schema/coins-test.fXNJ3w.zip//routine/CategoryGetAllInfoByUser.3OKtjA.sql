create
    definer = root@localhost procedure CategoryGetAllInfoByUser(IN cat_id int, IN u_id int)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Category info not found';
    SELECT cc.coinCategory, cc.id, cc.denomination, cc.typeCount,
      FuncCollectedCountByCategory(cat_id, u_id) AS catCount,
      FuncCollectionGetCategoryInvestment(cat_id, u_id) AS catInvest,
      FuncCollectedFaceValueByCategory(cat_id, u_id, cc.denomination) AS catFace
    FROM coincategories cc WHERE cc.id = cat_id;
  END;

