create
    definer = root@localhost function FuncGetTypeByID(c_id int) returns int
    comment 'Count of types by category'
    reads sql data
BEGIN
    DECLARE c_types VARCHAR(30);
    IF c_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Category cant be blank';
    END IF;
    SELECT c.cointypes_id
    INTO c_types
    FROM coins c
    WHERE c.id = c_id;
    RETURN c_types;
END;

