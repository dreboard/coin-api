create view viewgolddollartypes as
select distinct `ct`.`coinType`     AS `coinType`,
                `ct`.`denomination` AS `denomination`,
                `ct`.`id`           AS `id`,
                `ct`.`coincats_id`  AS `coincats_id`,
                `ct`.`dates`        AS `dates`
from (`coins-test`.`cointypes` `ct`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `ct`.`coincats_id`))
where `ct`.`id` in (65, 115, 55)
order by left(`ct`.`dates`, 4);

