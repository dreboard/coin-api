create
    definer = root@localhost procedure CoinVarietyGetByVarietyID(IN c_id int)
    comment 'Get all varieties by coin ID'
    reads sql data
BEGIN
        SELECT cv.id, cv.coin_id, cv.sub_type, cv.grouping, cv.variety, cv.label, cv.label, cv.designation, cv.type, cv.description,
               c.coinName, c.coinYear, c.coinMetal, c.strike, ct.coinType, ct.id AS type_id, cc.coinCategory, cc.id AS cat_id
        FROM coins_variety cv
        INNER JOIN coins c ON c.id = cv.coin_id
        INNER JOIN cointypes ct ON ct.id = c.cointypes_id
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE cv.id = c_id;
END;

