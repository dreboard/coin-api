create
    definer = root@localhost procedure CoinListTypeByYearMintmarks(IN c_type int)
    comment 'List of types same decade 1900.'
    reads sql data
BEGIN
    SELECT c.coinYear, GROUP_CONCAT(DISTINCT mintMark ORDER BY mintMark SEPARATOR ', ') as mintMarks
    FROM coins c
    INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.cointypes_id = c_type
    GROUP BY c.coinYear;
END;

