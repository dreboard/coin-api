create
    definer = root@localhost procedure CoinListTypeFromDecadeList(IN c_year int)
    comment 'Get coin TYPES same decade 1900.'
    reads sql data
BEGIN
    SELECT DISTINCT(ct.coinType)
        FROM cointypes ct
            INNER JOIN coins c ON c.cointypes_id = ct.id
            INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE coinYear LIKE CONCAT(SUBSTRING(c_year,1, 3), '%')
    ORDER BY cc.denomination;
END;

