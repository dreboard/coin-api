create
    definer = root@localhost procedure CoinListAllCoinBIEVarietyByYear(IN c_year int(10), IN c_var varchar(20))
    comment 'Get Liberty Broken Die list by year BIE type'
    reads sql data
BEGIN
    SELECT c.coinName, cv.description, cv.designation
    FROM coins_variety cv
             INNER JOIN coins c ON cv.coin_id = c.id
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.coinYear = c_year
      AND cv.`description` = c_var
      AND cv.`grouping` = 'Liberty Broken Die'
    ORDER BY cc.denomination;
END;

