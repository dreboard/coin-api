create
    definer = root@localhost procedure CollectedGradesCoinId(IN c_id int(10), IN u_id int(10))
    comment 'Get highest grade of coin id'
    reads sql data
BEGIN
    SELECT
           DISTINCT(co.coinGrade), COUNT(co.coinGrade) AS gradeCount
           -- ,CONCAT(FuncPrefixHighestGrade(c_id), ExtractNumber(MAX(co.coinGrade)))  AS highestGrade
	FROM collected co
	WHERE co.coinID = c_id AND co.userID = u_id GROUP BY co.coinGrade ORDER BY co.coinGrade DESC
    ;
  END;

