create
    definer = root@localhost procedure CommemorativeGetCats()
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'commemoratives not found';
    SELECT * FROM commemorativeCategoriesView;
  END;

