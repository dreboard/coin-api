create
    definer = root@localhost procedure CoinGetAllProofMetalBullionFromYear(IN c_year int, IN c_metal varchar(20))
    comment 'Get All Proof Bullion coins From a Year by metal'
    reads sql data
BEGIN
    SELECT coins.id, coins.coinName, coins.coinType, coins.coinYear, coins.coinVersion
        FROM coins
    INNER JOIN coincategories cc ON cc.id = coins.coincats_id
        WHERE coins.coinYear = c_year
          AND coins.coinMetal = c_metal
          AND coins.strike IN ('Proof', 'Reverse Proof')
    ORDER BY cc.denomination;

END;

