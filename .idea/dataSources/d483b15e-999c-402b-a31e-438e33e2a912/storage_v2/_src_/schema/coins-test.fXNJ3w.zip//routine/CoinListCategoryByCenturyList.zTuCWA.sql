create
    definer = root@localhost procedure CoinListCategoryByCenturyList(IN c_year int)
    comment 'Get coin TYPESsame decade 1900.'
    reads sql data
BEGIN
    SELECT DISTINCT(cc.coinCategory)
        FROM coincategories cc
            INNER JOIN coins c ON c.coincats_id = cc.id
    WHERE c.coinYear LIKE CONCAT(SUBSTRING(c_year,1, 2), '%')
    ORDER BY cc.denomination;
END;

