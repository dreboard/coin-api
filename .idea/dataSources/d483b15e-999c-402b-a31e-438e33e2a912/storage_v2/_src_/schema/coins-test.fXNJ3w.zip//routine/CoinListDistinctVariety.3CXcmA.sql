create
    definer = root@localhost procedure CoinListDistinctVariety() comment 'Get variety with same coinID.' reads sql data
BEGIN
      SELECT DISTINCT (cv.variety)
      FROM coins_variety cv
      ORDER BY udf_NaturalSortFormat(cv.variety, 15, ".");
  END;

