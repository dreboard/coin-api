create
    definer = root@localhost function FuncCollectionGetTypeInvestment(type_id int, u_id int) returns float
    comment 'Get sum of category investment'
    reads sql data
BEGIN
    DECLARE invested FLOAT;
    SELECT COALESCE(sum(cp.purchasePrice), 0.00)
    INTO invested
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
             INNER JOIN coins c ON c.id = co.coinID
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
    WHERE co.userID = u_id
      AND ct.id = type_id;
    RETURN invested;
END;

