create
    definer = root@localhost procedure CoinListDistinctVarietyByCoinId(IN c_id int)
    comment 'Get list of DISTINCT varieties by coin ID'
    reads sql data
BEGIN
    SELECT DISTINCT variety FROM `coins_variety` WHERE coin_id = c_id;
END;

