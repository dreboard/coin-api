create
    definer = root@localhost procedure CoinAllCoinsByTypeFromYear(IN c_year int, IN c_type int)
    comment 'List of all coins by type from a year'
    reads sql data
BEGIN
    SELECT c.id, c.coinName, ct.coinType, c.coinYear, c.coinVersion
        FROM coins c
            INNER JOIN cointypes ct ON c.cointypes_id = ct.id
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.coinYear = c_year AND c.cointypes_id = c_type  ORDER BY cc.denomination, c.cointypes_id;
END;

