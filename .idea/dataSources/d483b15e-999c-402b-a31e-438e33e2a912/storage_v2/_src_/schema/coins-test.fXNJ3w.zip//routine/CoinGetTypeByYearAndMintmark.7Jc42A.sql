create
    definer = root@localhost procedure CoinGetTypeByYearAndMintmark(IN c_year int, IN c_type int, IN c_mark varchar(2))
    comment 'List of types and mintmarks by year'
    reads sql data
BEGIN
    SELECT c.id,
           c.mintMark,
           c.coinYear,
           cc.coinCategory,
           ct.coinType,
           c.coinName,
           c.coinVersion,
           c.coinMetal,
           c.strike,
           cc.denomination
    FROM coins c
             INNER JOIN cointypes ct ON ct.id = c.cointypes_id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coinYear = c_year AND c.mintMark = c_mark AND c.cointypes_id = c_type
    GROUP BY c.coinYear;
END;

