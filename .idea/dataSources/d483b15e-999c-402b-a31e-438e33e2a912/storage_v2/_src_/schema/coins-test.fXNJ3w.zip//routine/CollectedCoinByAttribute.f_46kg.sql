create
    definer = root@localhost procedure CollectedCoinByAttribute(IN c_id int(10), IN u_id int(10), IN c_att varchar(5))
    comment 'Get colors count by coin idr'
    reads sql data
BEGIN
    SELECT
           co.fullAtt, COUNT(co.fullAtt) AS fullBellCount,
           CONCAT(FuncPrefixHighestGrade(c_id), ExtractNumber(MAX(co.coinGrade)))  AS highestGrade
	FROM collected co
    INNER JOIN coins c ON c.id = co.coinID
	WHERE co.coinID = c_id AND co.fullAtt = c_att AND co.userID = u_id GROUP BY co.fullAtt ORDER BY co.fullAtt ASC;
  END;

