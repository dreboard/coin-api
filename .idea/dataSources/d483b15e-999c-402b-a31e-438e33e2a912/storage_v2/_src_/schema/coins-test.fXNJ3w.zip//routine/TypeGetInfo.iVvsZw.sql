create
    definer = root@localhost procedure TypeGetInfo(IN c_type int)
BEGIN
    SELECT ct.coinType, ct.id, ct.dates, ct.mintMarks, cc.coinCategory, ct.id,
           cc.id AS cat_id
    FROM cointypes ct
    INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE ct.id = c_type;
END;

