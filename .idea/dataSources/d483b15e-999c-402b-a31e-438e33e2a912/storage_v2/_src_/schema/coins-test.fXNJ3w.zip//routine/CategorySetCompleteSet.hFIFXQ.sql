create
    definer = root@localhost procedure CategorySetCompleteSet()
    comment 'Get all commemorative version type coins'
    modifies sql data
BEGIN

		DECLARE c_cat VARCHAR(255);
		DECLARE v_finished INTEGER DEFAULT 0;
		DECLARE coinTypeCusor CURSOR FOR SELECT coinCategory FROM `coincategories` ORDER BY `coincategories`.`denomination` ASC ;

		 -- declare NOT FOUND handler
		DECLARE CONTINUE HANDLER
				FOR NOT FOUND SET v_finished = 1;

		OPEN coinTypeCusor;
		get_coinType: LOOP
		 
			FETCH coinTypeCusor INTO c_cat;
			IF v_finished = 1 THEN
				LEAVE get_coinType;
			END IF;
			
			UPDATE `coincategories` SET `typeCount` = FuncCompleteTypeCountByCategory(c_cat) WHERE coinCategory = c_cat ;
		 
		END LOOP get_coinType;
		CLOSE coinTypeCusor;

	END;

