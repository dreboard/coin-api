create
    definer = root@localhost procedure CoinListAllBullionTypesFromYear(IN c_year int)
    comment 'Get All Bullion coin types From a Year'
    reads sql data
BEGIN
        SELECT DISTINCT(ct.coinType)
        FROM cointypes ct
            INNER JOIN coins c ON c.cointypes_id = ct.id
            INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.coinYear = c_year AND c.coinMetal IN ('Gold', 'Platinum', 'Palladium')
    ORDER BY cc.denomination;
END;

