create view viewdistinctcenturies as
select distinct `coins-test`.`coins`.`century` AS `century`
from `coins-test`.`coins`
order by `coins-test`.`coins`.`century`;

