create
    definer = root@localhost procedure CoinsGetLikeID(IN p_id int)
    comment 'Get coins with same year, type and mint mark.'
    reads sql data
BEGIN

    DECLARE likeCoinYear INT(4);
    DECLARE likeCoinMark VARCHAR(10);
    DECLARE likeCoinType VARCHAR(100);

    SET likeCoinYear = (SELECT coins.coinYear FROM coins WHERE coins.id = p_id);
    SET likeCoinMark = (SELECT coins.mintMark FROM coins WHERE coins.id = p_id);
    SET likeCoinType = (SELECT coins.coinType FROM coins WHERE coins.id = p_id);

    SELECT id, mintMark, coinYear, coinCategory, coinType, coinName, coinVersion, coinMetal, strike
	FROM coins
    WHERE coinType = likeCoinType
    AND mintMark = likeCoinMark
    AND coinYear = likeCoinYear;
  END;

