create
    definer = root@localhost procedure CollectionGetTypeInvestment(IN u_id int, IN c_type int)
    comment 'Get total investment by type'
    reads sql data
BEGIN
    SELECT COALESCE(sum(cp.purchasePrice), 0.00) AS invested
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
             INNER JOIN coins c ON c.id = co.coinID
    WHERE co.userID = u_id
      AND c.cointypes_id = c_type;
END;

