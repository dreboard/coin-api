create view viewerrorcategories as
select distinct `ce`.`category` AS `category`
from `coins-test`.`coins_errors` `ce`
order by `ce`.`category`;

-- comment on column viewerrorcategories.category not supported:  Die Errors

