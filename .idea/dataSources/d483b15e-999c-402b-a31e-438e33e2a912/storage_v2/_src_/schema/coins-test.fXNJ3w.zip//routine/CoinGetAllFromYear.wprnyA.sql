create
    definer = root@localhost procedure CoinGetAllFromYear(IN cy int) comment 'Get all coins from a year.' reads sql data
BEGIN
    PREPARE dynamic_statement FROM
    'SELECT c.id, c.coinName, ct.coinType, ct.id AS type_id, c.coinYear, c.coinVersion, cc.denomination, cc.coinCategory, cc.id AS cat_id
    FROM coins c
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = c.coincats_id
    WHERE c.coinYear = ?
    ORDER BY c.denomination';
    EXECUTE dynamic_statement USING cy;
    DEALLOCATE PREPARE dynamic_statement;
END;

