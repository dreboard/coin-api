create
    definer = root@localhost function FuncCollectedCountByCategory(cat_id int, u_id int) returns int
    comment 'Get sum of category investment'
    reads sql data
BEGIN
    DECLARE saved INT;
    SELECT COUNT(co.id)
    INTO saved
    FROM collected co
             INNER JOIN coins c ON c.id = co.coinID
             INNER JOIN coincategories cc ON c.coincats_id = cc.id
    WHERE co.userID = u_id
      AND cc.id = cat_id;
    RETURN FORMAT(saved, 3);
END;

