create
    definer = root@localhost function commemorativeGetCoinVersion(type varchar(20)) returns varchar(20)
BEGIN
    DECLARE cv VARCHAR(20);
    SELECT coinVersion INTO cv FROM coins WHERE coinType = type;

    RETURN type;
  END;

