create
    definer = root@localhost function FuncCountCollectedByType(u_id int, t_id int) returns text
    comment 'Get count of different design types'
    reads sql data
BEGIN
    DECLARE typesCount INT;
    SELECT COUNT(co.id)
    INTO typesCount
    FROM collected co
    INNER JOIN coins c ON co.coinID = c.id
    WHERE c.cointypes_id = t_id AND co.userID = u_id;
    RETURN typesCount;
END;

