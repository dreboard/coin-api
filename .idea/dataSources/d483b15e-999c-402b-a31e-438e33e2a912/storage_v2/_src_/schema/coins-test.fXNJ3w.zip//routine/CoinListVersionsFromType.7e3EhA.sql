create
    definer = root@localhost procedure CoinListVersionsFromType(IN c_type int)
    comment 'Get list of versions by type'
    reads sql data
BEGIN

    SELECT DISTINCT(c.coinVersion)
    FROM coins c
             INNER JOIN cointypes ct ON c.cointypes_id = ct.id
             INNER JOIN coincategories cc ON cc.id = ct.coincats_id
    WHERE c.cointypes_id = c_type
    ORDER BY cc.denomination;

END;

