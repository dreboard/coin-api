create
    definer = root@localhost procedure clean(IN schemaName varchar(20), IN tableName varchar(20))
BEGIN

    DECLARE done INT DEFAULT 0;
    DECLARE log_cnt INT DEFAULT 0;
    DECLARE col_name VARCHAR(255);
    DECLARE col_cur CURSOR FOR SELECT COLUMNS.COLUMN_NAME
                               FROM information_schema.COLUMNS
                               WHERE COLUMNS.TABLE_SCHEMA = schemaName
                                 AND COLUMNS.TABLE_NAME = tableName;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
    OPEN col_cur;
    read_loop:
    LOOP
        FETCH col_cur INTO col_name;
        IF done THEN
            LEAVE read_loop;
        END IF;
        SET @stmt_text =
                CONCAT("UPDATE `", schemaName, "`.`", tableName, "` SET `", col_name, "`=TRIM(`", col_name, "`);");
        PREPARE stmt FROM @stmt_text;
        EXECUTE stmt;
        SET @affected = ROW_COUNT();
        SET log_cnt = log_cnt + @affected;

    END LOOP;
    CLOSE col_cur;
    SELECT CONCAT(log_cnt, " instances were cleaned!!");
END;

