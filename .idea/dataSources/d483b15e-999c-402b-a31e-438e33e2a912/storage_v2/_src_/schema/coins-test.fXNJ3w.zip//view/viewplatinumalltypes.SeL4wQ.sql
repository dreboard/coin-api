create view viewplatinumalltypes as
select distinct `ct`.`coinType` AS `coinType`
from ((`coins-test`.`coins` `c` join `coins-test`.`cointypes` `ct` on (`c`.`cointypes_id` = `ct`.`id`))
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinMetal` = 'Platinum'
order by `cc`.`denomination`;

