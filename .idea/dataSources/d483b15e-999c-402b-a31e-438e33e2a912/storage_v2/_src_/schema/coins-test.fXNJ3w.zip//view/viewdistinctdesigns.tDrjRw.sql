create view viewdistinctdesigns as
select distinct `coins-test`.`coins`.`design` AS `design`
from `coins-test`.`coins`
where `coins-test`.`coins`.`design` <> 'None'
  and `coins-test`.`coins`.`design` <> ''
order by `coins-test`.`coins`.`design`;

