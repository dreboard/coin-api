create
    definer = root@localhost procedure EnterFinanceByCoin(IN u_id int) comment 'Enter Finance By Coin' modifies sql data
BEGIN

    DECLARE collected_id INTEGER;
    DECLARE v_finished INTEGER DEFAULT 0;
    DECLARE coinTypeCusor CURSOR FOR SELECT co.id FROM `collected` co WHERE userID = u_id;

    -- declare NOT FOUND handler
    DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

    OPEN coinTypeCusor;
    get_coinType:
    LOOP
        FETCH coinTypeCusor INTO collected_id;
        IF v_finished = 1 THEN
            LEAVE get_coinType;
        END IF;
        INSERT INTO collected_purchase (collected_id, purchasePrice) VALUES (collected_id, '10.00');

    END LOOP get_coinType;
    CLOSE coinTypeCusor;

END;

