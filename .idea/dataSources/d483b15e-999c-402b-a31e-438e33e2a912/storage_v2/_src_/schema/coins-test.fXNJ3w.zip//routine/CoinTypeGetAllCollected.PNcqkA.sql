create
    definer = root@localhost procedure CoinTypeGetAllCollected(IN type varchar(100), IN id int(100))
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION SELECT 'Collected type not found';
    SELECT * FROM collection
    INNER JOIN coins ON collection.coinID = coins.coinID
    WHERE coins.coinType = type AND collection.userID = id
    ORDER BY coins.coinYear ASC;
  END;

