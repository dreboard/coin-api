create
    definer = root@localhost function FuncCollectTypeInvestment(c_type int, u_id int(10)) returns decimal(10, 2)
    comment 'Returns total investment by type'
    reads sql data
BEGIN
    DECLARE returnVal DECIMAL(10,3) DEFAULT 0.00;
    SELECT COALESCE(ROUND(sum(cp.purchasePrice), 2), 0.00)
    INTO returnVal
    FROM collected_purchase cp
             INNER JOIN collected co ON co.id = cp.collected_id
             INNER JOIN coins c ON co.coinID = c.id
             INNER JOIN cointypes ct ON ct.id = c.cointypes_id
    WHERE co.userID = u_id
      AND ct.id = c_type;
    RETURN returnVal; 
END;

