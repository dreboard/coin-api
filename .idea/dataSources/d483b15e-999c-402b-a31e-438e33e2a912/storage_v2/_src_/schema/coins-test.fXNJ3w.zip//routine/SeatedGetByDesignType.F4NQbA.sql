create
    definer = root@localhost procedure SeatedGetByDesignType(IN seated_type varchar(50), IN c_type int)
    comment 'Set cointype field'
    reads sql data
BEGIN
    SELECT c.id, c.coinSubCategory, c.coinName, c.coinYear, c.mintMark, c.coinVersion, c.designType, c.obv, c.obv2, c.rev, c.rev2
        FROM coins c
        INNER JOIN coincategories cc ON cc.id = c.coincats_id
        WHERE c.designType = seated_type AND c.cointypes_id = c_type ORDER BY cc.denomination;
  END;

