create view allcategorieslist as
select distinct `coins-test`.`coins`.`coinCategory` AS `coinCategory`
from `coins-test`.`coins`
order by `coins-test`.`coins`.`denomination` desc;

