create
    definer = root@localhost function FuncCollectionCountCoinByUser(u_id int, c_id int) returns int
    comment 'Count of coins id saved by user'
    reads sql data
BEGIN
    DECLARE coinCollected INT;
    SELECT COUNT(co.coinID)
    INTO coinCollected
    FROM collected co
    WHERE co.userID = u_id
      AND co.coinID = c_id;
    RETURN coinCollected;
END;

