create
    definer = root@localhost procedure CoinGetAllBullionFromYear(IN c_year int)
    comment 'Get Commemorative all same year.'
    reads sql data
BEGIN
    SELECT id, coinName, coinType, coinYear, coinVersion
        FROM coins
        WHERE coins.coinYear = c_year AND coins.coinMetal IN ('Gold', 'Platinum', 'Palladium')  ORDER BY coins.denomination;

END;

