create
    definer = root@localhost procedure CoinGetByID(IN id int)
BEGIN
SELECT *
FROM coins
WHERE coinID = id;
END;

