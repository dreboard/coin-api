create
    definer = root@localhost procedure CommemorativeSetType()
BEGIN

DECLARE coinID INT(10);
DECLARE v_finished INTEGER DEFAULT 0;
DECLARE coinTypeCusor CURSOR FOR SELECT id FROM `coins` WHERE `cointypes_id` = 31;-- AND coinYear > 2012 ORDER BY `coinYear` ASC;

 -- declare NOT FOUND handler
DECLARE CONTINUE HANDLER
        FOR NOT FOUND SET v_finished = 1;

OPEN coinTypeCusor;
get_coinType: LOOP
 
    FETCH coinTypeCusor INTO coinID;
    IF v_finished = 1 THEN
        LEAVE get_coinType;
    END IF;
    
    UPDATE `coins` SET `commemorativeType` = SUBSTRING(coinName, 7) WHERE id = coinID ;
 
END LOOP get_coinType;
CLOSE coinTypeCusor;

END;

