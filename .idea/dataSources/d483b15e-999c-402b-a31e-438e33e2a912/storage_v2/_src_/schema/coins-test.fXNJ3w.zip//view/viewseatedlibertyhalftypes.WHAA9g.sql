create view viewseatedlibertyhalftypes as
select distinct `c`.`designType` AS `designType`
from `coins-test`.`coins` `c`
where `c`.`cointypes_id` = 57
order by `c`.`designType`;

