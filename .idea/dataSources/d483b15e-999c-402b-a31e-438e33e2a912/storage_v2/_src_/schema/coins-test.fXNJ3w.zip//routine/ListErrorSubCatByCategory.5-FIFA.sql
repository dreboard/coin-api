create
    definer = root@localhost procedure ListErrorSubCatByCategory(IN e_cat varchar(50))
    comment 'Get highest grade of coin id'
    reads sql data
BEGIN
    SELECT
           DISTINCT(co.sub_category)
	FROM coins_errors co
	WHERE co.category = e_cat ORDER BY co.sub_category;
  END;

