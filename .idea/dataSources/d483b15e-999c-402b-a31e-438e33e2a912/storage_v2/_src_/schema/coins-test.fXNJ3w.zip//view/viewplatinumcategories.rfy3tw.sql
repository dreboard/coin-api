create view viewplatinumcategories as
select distinct `cc`.`coinCategory` AS `coinCategory`
from (`coins-test`.`coins` `c`
         join `coins-test`.`coincategories` `cc` on (`cc`.`id` = `c`.`coincats_id`))
where `c`.`coinMetal` = 'Platinum'
  and `cc`.`id` <> 29
order by `cc`.`denomination`;

