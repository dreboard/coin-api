create
    definer = root@localhost procedure CoinGetAllCommemorativeFromYear(IN cy int)
    comment 'Get coins all same year.'
    reads sql data
BEGIN
    PREPARE dynamic_statement FROM
        'SELECT id, coinName, coinType, coinYear, coinVersion
        FROM coins
        WHERE coins.coinYear = ? AND  coins.commemorative = 1 ORDER BY coins.denomination';
    EXECUTE dynamic_statement USING cy;
    DEALLOCATE PREPARE dynamic_statement;
END;

