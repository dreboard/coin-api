create
    definer = root@localhost function FuncCountByColorAndCoinId(c_id int(10), c_color varchar(10), u_id int(10)) returns int
    comment 'Get count of color'
    reads sql data
BEGIN
    DECLARE colorCount INT;
    SELECT COUNT(co.color) INTO colorCount
    FROM collected2 co
    WHERE co.coinID = c_id
      AND co.color = c_color
      AND co.userID = u_id;
    RETURN colorCount;
END;

