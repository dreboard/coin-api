create
    definer = root@localhost procedure CollectedTypeGetInfo(IN type varchar(100), IN u_id int(100))
    comment 'Get info on types'
    reads sql data
BEGIN
    SELECT FuncCollectionGetTypeInvestment(type, u_id) AS typeInvest,
           FuncCountCollectedByType(u_id,type) AS typeCount;
  END;

