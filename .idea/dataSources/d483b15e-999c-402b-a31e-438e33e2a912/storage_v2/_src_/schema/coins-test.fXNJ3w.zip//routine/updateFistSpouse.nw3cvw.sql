create
    definer = root@localhost procedure updateFistSpouse(IN relNum int, IN des_type varchar(255))
    comment 'Update coin release number'
    modifies sql data
BEGIN
    START TRANSACTION;
        UPDATE `coins` SET `release` = relNum WHERE `coinName` LIKE CONCAT('%', des_type , '%') AND `cointypes_id` = 122;
        UPDATE `coins` SET `design` = des_type WHERE `coinName` LIKE CONCAT('%', des_type , '%') AND `cointypes_id` = 122;
        SELECT * FROM `coins` WHERE `design` LIKE CONCAT('%', des_type , '%') AND `cointypes_id` = 122;
    COMMIT;
END;

